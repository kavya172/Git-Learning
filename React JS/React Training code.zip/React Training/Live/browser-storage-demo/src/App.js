import logo from './logo.svg';
import './App.css';
import LocalStorageDemo from './components/LocalStorageDemo';
import ReactCookie from './components/ReactCookie';
// import UseDefferedValueDemo from './components/UseDefferedValueDemo';
import MovieList from './components/MovieList';

function App() {
  return (
    <div className="">
      {/* <LocalStorageDemo/> */}
      {/* <ReactCookie/> */}
      {/* <UseDefferedValueDemo/> */}
      <MovieList/>
    </div>
  );
}

export default App;
