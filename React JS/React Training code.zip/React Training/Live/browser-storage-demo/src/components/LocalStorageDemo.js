import React, { useEffect, useState } from 'react'

const LocalStorageDemo = () => {
    const [username, setUsername] = useState('');
    const [storedUsername, setStoredUsername] = useState('');
  
    useEffect(() => {
        localStorage.setItem("demo","demo")
      const savedUsername = localStorage.getItem('username');
      if (savedUsername) {
        setStoredUsername(savedUsername);
      }
    }, []);
  
    const saveToLocalStorage = () => {
      localStorage.setItem('username', username);
      setStoredUsername(username);
      setUsername(''); 
    };
  
    const removeFromLocalStorage = () => {
      localStorage.removeItem('username');
      setStoredUsername('');
    };
  
    const clearLocalStorage = () => {
      localStorage.clear();
      setStoredUsername('');
    };
  
    return (
      <div>
        <h2>LocalStorage Demo</h2>
        
        <div>
          <label>Enter Username: </label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <button onClick={saveToLocalStorage}>Save to localStorage</button>
        </div>
        
        <div>
          <h3>Stored Username in localStorage: {storedUsername || 'No username stored'}</h3>
        </div>
  
        <div>
          <button onClick={removeFromLocalStorage}>Remove Username from localStorage</button>
          <button onClick={clearLocalStorage}>Clear All localStorage</button>
        </div>
      </div>
    );
}

export default LocalStorageDemo
