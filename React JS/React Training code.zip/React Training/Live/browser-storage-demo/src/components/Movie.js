import React, { useState } from 'react'

const Movie = ({movie}) => {
    const [count, setCount] = useState(1)

  return (
    <div key={movie.id} className="movie-card">
            <img src={movie.img} alt={movie.movieName} className="movie-img" />
            <div className="movie-details">
              <h3>{movie.movieName}</h3>
              <p><strong>Price:</strong> ₹{movie.price}</p>
              <p><strong>Rating:</strong> {movie.rating}</p>
              <p><strong>Genre:</strong> {movie.genre.map(genre=>genre+ " ")}</p>
              <p><strong>Language:</strong> {movie.language}</p>
            </div>
            <button onClick={()=>setCount(count-1)}>-</button>
            &nbsp;&nbsp;{count}&nbsp;&nbsp;
            <button onClick={()=>setCount(count+1)}>+</button>
          </div>
  )
}

export default Movie
