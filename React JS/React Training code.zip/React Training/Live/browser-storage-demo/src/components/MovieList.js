import React, { useState, useEffect } from 'react';

import axios from 'axios'
import Movie from './Movie';

const MovieList = () => {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const resp = await axios.get("https://mocki.io/v1/7df2781a-757d-4374-9aca-5a7b4563e601");
        setMovies(resp.data);
      } catch (error) {
        console.error("Error fetching movies:", error);
      }
    };

    fetchMovies();
  }, []);

  return (
    <div className="movie-list">
      <h1>Movie List</h1>
      <div className="movies">
        {movies.map(movie => (
          <Movie movie={movie}/>
        ))}
      </div>
    </div>
  );
};

export default MovieList;
