import React from 'react'
import { useEffect } from 'react';
import { useState } from 'react';
import { useCookies } from 'react-cookie'
import './Movielist.css'

const ReactCookie = () => {
    const [cookies, setCookie, removeCookie] = useCookies(["user"]);
    const [username, setUsername] = useState('');
  
    const saveUsername = () => {
      setCookie('user', username, { path: '/' });
      setUsername('');
    };
  
    const removeUsername = () => {
      removeCookie('user');
    };
  
    return (
      <div>
        <h2>React Cookie Demo</h2>
        
        <div>
          <label>Enter Username: </label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <button onClick={saveUsername}>Save to Cookies</button>
        </div>
  
        <div>
          <h3>Stored Username: {cookies.user || 'No username stored'}</h3>
        </div>
  
        <div>
          <button onClick={removeUsername}>Remove Username from Cookies</button>
        </div>
      </div>
    );
}

export default ReactCookie
