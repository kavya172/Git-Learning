import logo from './logo.svg';
import './App.css';
import EventObjectDemo from './components/EventObjectDemo';
import OnFocusDemo from './components/OnFocusDemo';
import OnMouseEnterDemo from './components/OnMouseEnterDemo';
import EventPropagationDemo from './components/event-propagation/EventPropagationDemo';
import PreventDefaultDemo from './components/PreventDefaultDemo';

function App() {
  return (
    <div className="App">
      {/* <EventObjectDemo/> */}
      {/* <OnMouseEnterDemo/> */}
      {/* <OnFocusDemo/> */}
      {/* <EventPropagationDemo/> */}
      <PreventDefaultDemo/>
    </div>
  );
}

export default App;
