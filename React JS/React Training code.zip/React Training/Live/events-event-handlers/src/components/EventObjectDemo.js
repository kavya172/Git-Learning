import React from "react";

const EventObjectDemo = () => {
  const handleClick = (event) => {
    console.log(event);
  };

  const handleKeyDown = (e) => {
    console.log("Key Down", e);
  };

  const handleKeyUp = (e) => {
    console.log("Key Up", e);
  };
  const handleKeyPress = (e) => {
    console.log("Key Press", e);
  };

  const handleFocus = (e) => {
    console.log("Text box focused", e);
  };

  const handleChange = (e) => {
    console.log("On change", e)
  }

  const handleInput = (e) => {
    console.log("On input", e)
  }

  return (
    <div>
      <button onClick={handleClick}>CLICK</button>
      <input
        // type="text"
        // onKeyDown={handleKeyDown}
        // onKeyUp={handleKeyUp}
        // onKeyPress={handleKeyPress}
        // onFocus={handleFocus}
        onChange={handleChange}
        // onInput={handleInput}
      />
    </div>
  );
};

export default EventObjectDemo;
