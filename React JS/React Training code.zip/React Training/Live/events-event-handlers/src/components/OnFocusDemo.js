import React, { useState } from 'react'

const OnFocusDemo = () => {
    const [focused, setFocused] = useState(false);

    return (
      <input
        type="text"
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          backgroundColor: focused ? 'lightyellow' : 'white',
          borderColor: focused ? 'blue' : 'gray',
          padding: '10px',
        }}
      />
    );
}

export default OnFocusDemo
