import React, { useState } from 'react'

const OnMouseEnterDemo = () => {
    const [showTooltip, setShowTooltip] = useState(false);

    const handleMouseEnter = () => {
      setShowTooltip(true);
    };
  
    const handleMouseLeave = () => {
      setShowTooltip(false);
    };
  
    return (
      <div>
        <button onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Hover over me
        </button>
        {showTooltip && <div className="tooltip">This is additional information!</div>}
      </div>
    );
}

export default OnMouseEnterDemo
