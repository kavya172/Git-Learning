import React, { useState } from 'react'

const PreventDefaultDemo = () => {
    const [inputValue, setInputValue] = useState("");

    const handleSubmit = (e) => {
      e.preventDefault();
      alert(`Form submitted with input: ${inputValue}`);
    };
  
    const handleChange = (e) => {
      setInputValue(e.target.value);
    };

    const handleClick = (e) => {
        e.preventDefault();
        console.log(e)
        alert("Link clicked, but default navigation prevented!");
      };
  
    return (
      <div>
        <h1>Prevent Default Example</h1>
        <form onSubmit={handleSubmit}>
          <label>
            Name:
            <input
              type="text"
              value={inputValue}
              onChange={handleChange}
              placeholder="Enter your name"
            />
          </label>
          <button type="submit">Submit</button>
        </form>

        <a href="https://www.example.com" onClick={handleClick}>
        Click me to prevent default navigation
      </a>
      </div>
    );
}

export default PreventDefaultDemo
