import React from "react";
import styles from "./EventPropagationDemo.module.css";

const EventPropagationDemo = () => {
  const handleOuterDivClick = (e, text) => {
    console.log("CurrentTarget", e.currentTarget)
    console.log("Target", e.target)

    // console.log("text", text);
  };

  const handleMiddleDivClick = (e, text) => {
    // console.log("text", text);
  };

  const handleInnerDivClick = (e, text) => {
    // e.stopPropagation()
    // console.log("text", text);
  };

  return (
    <div
      className={styles.outerDiv}
      onClick={(e) => handleOuterDivClick(e, "Outer DIV: Bubble")}
      // onClickCapture={(e) => handleOuterDivClick(e, "Outer DIV: Capture")}
    >
      <div
        className={styles.middleDiv}
        onClick={(e) => handleMiddleDivClick(e, "Middle DIV: Bubble")}
        // onClickCapture={(e) => handleMiddleDivClick(e, "Middle DIV: Capture")}
      >
        <div
          className={styles.innerDiv}
          onClick={(e) => handleInnerDivClick(e, "Inner DIV: Bubble")}
          // onClickCapture={(e) => handleInnerDivClick(e, "Inner DIV: Capture")}
        >
          <p>This is the innermost div!</p>
        </div>
      </div>
    </div>
  );
};

export default EventPropagationDemo;
