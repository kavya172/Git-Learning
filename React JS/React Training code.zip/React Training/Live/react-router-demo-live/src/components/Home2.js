import React from 'react'

const Home2 = () => {
  return (
    <div>
      <h1>This is second home page</h1>
    </div>
  )
}

export default Home2
