import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import './Navbar.css'

const Navbar = () => {
  return (
    <div>
      <nav>
        <NavLink to='/' className={(element)=>element.isActive?"red":""}><li>Home</li></NavLink>
        <NavLink to='/about'  className={(element)=>element.isActive?"red":""}><li>About</li></NavLink>
        <NavLink to='/portfolio'  className={(element)=>element.isActive?"red":""}><li>Portfolio</li></NavLink>
      </nav>
    </div>
  )
}

export default Navbar
