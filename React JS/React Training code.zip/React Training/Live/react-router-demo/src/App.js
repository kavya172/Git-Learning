import logo from "./logo.svg";
import "./App.css";
import About from "./components/About";
import Home from "./components/Home";
import PortFolio from "./components/Portfolio";
import Navbar from "./components/Navbar/Navbar";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import PageNotFound from "./components/PageNotFound";
import Home2 from "./components/Home2";
import User from "./components/User";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <br />
      <br />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/" element={<Home2 />} />
        <Route path="/about" element={<About />} />
        <Route path="/portfolio" element={<PortFolio />} />
        <Route path="/user/:username" element={<User/>}/>
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
