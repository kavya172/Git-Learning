import React from 'react'

const PortFolio = () => {
  return (
    <div>
      <h1>This is Portfolio Page</h1>
    </div>
  )
}

export default PortFolio
