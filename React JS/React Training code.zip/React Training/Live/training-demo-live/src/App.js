import logo from './logo.svg';
import './App.css';
import UseMemoDemo from './components/useMemo/UseMemoDemo';
import ParentComponent from './components/reactMemo/ParentComponent';
import UseCallbackDemo from './components/useCallback/UseCallbackDemo';
import CustomHookDemo from './components/customHooks/CustomHookDemo';
import CustomHookDemo2 from './components/customHooks/CustomHookDemo2';
import UseTransitionDemo from './components/useTransition/UseTransitionDemo';
import UseDeferredValueDemo from './components/usedeferredValue/UseDeferredValueDemo';
import UseEffectDemo from './components/useMemo/UseEffectDemo';

function App() {
  return (
    <div className="App">
      {/* <UseMemoDemo/> */}
      {/* <UseEffectDemo/> */}
      {/* <ParentComponent/> */}
      {/* <UseCallbackDemo/> */}
      {/* <CustomHookDemo/> */}
      {/* <CustomHookDemo2/> */}
      {/* <UseTransitionDemo/> */}
      <UseDeferredValueDemo/>
    </div>
  );
}

export default App;
