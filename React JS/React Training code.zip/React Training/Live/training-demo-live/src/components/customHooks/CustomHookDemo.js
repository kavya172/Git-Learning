import React, { useState } from "react";
import useCounter from "./useCounter";

const CustomHookDemo = () => {
  const [counter, increment] = useCounter(10);
  
  return (
    <div>
      <h1>{counter}</h1>
      <button onClick={increment}>INCR</button>
    </div>
  );
};

export default CustomHookDemo;
