import React, {memo} from 'react'

const ChildComponent = memo(() => {
    console.log("Child rendered")
  return (
    <div>
      <h1>This is child component</h1>
    </div>
  )
});

export default ChildComponent
