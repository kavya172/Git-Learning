import React, { useState } from 'react'
import ChildComponent from './ChildComponent'

const ParentComponent = () => {
    console.log("Parent rendered")

    const [counter, setCounter] = useState(0)
  return (
    <div>
      <h1>This is parent</h1>
      <h2>{counter}</h2>
      <button onClick={()=>setCounter(counter+1)}>INCR</button>
      <hr/>
      <ChildComponent/>
    </div>
  )
}

export default ParentComponent
