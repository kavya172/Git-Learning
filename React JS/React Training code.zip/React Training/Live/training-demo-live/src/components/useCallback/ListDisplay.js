import React, { memo } from "react";

const ListDisplay = ({ list, addToList }) => {
    
  // console.log("Child Rendered");

  return (
    <div>
			<h1>This is Child Component</h1>
      <h2>List</h2>
      {list.map((item) => (
        <h3>{item}</h3>
      ))}
      <button onClick={() => addToList("Item No " + (list.length + 1))}>
        Add
      </button>
    </div>
  );
};

export default memo(ListDisplay);
