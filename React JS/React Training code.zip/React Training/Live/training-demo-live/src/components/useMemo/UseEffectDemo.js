import React, { useEffect, useState } from 'react'

const UseEffectDemo = () => {
  const [text, setText] = useState("");  
  const [counter, setCounter] = useState(0)

  const [tempValue, setTempValue] = useState(0)

  const handleTextChange = (e) => {
    setText(e.target.value);
  };

  const getTempValue = () => {
    console.log("Inside getTempValue");
    const SIZE = 100000000;
    let sum = 0;
    for (let i = 0; i < SIZE; i++) {
       sum = i + sum;
    }
    return counter*2;
  };

  useEffect(()=>{
    setTempValue(getTempValue())
  },[counter])

  const showAlert = () => {
    alert("Temp value: "+ tempValue)
  }

  const increment = () => {
    setCounter(counter+1)
  }


  return (
    <div style={{padding: 10}}>
      <input type="text" value={text} onChange={handleTextChange} />
      <h2>Entered Text</h2>
      <h1>{text}</h1>
      <hr/>
      <h1>{counter}</h1>
      <button onClick={increment}>Incr</button><br/><br/>
      <hr/>
      <button onClick={showAlert}>Show Temp Value</button>
    </div>
  )
}

export default UseEffectDemo
