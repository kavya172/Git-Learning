import React, { useMemo } from "react";

const List = ({ search }) => {
  const SIZE = 10000;

  const list = useMemo(() => {
    const l = [];
    for (let i = 0; i < SIZE; i++) {
      l.push(<div>{search}</div>);
    }
    return l;
  }, [search]);

  return list;
};

export default List;
