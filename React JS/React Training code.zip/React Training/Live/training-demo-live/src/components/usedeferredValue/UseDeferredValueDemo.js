import React, { useDeferredValue, useMemo, useState } from "react";
import List from "./List";

const UseDeferredValueDemo = () => {
  const [search, setSearch] = useState("");
  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  }

  return (
    <div>
      <h1>useDeferredValue Demo</h1>
      <input type="text" value={search} onChange={handleSearchChange} />

      <List search={useDeferredValue(search)}/>
    </div>
  );
};

export default UseDeferredValueDemo;
