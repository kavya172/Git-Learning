import logo from './logo.svg';
import './App.css';
import {useSelector, useDispatch} from 'react-redux'
import { decrement, increment, incrementByNum } from './features/counter/CounterSlice';
import Demo from './components/Demo';

function App() {

  const count = useSelector((state)=>state.counter.value);

  const dispatch = useDispatch();

  return (
    <div className="App">
      <h1>{count}</h1>
      <button onClick={()=>dispatch(increment())}>INCR</button>
      <button onClick={()=>dispatch(decrement())}>DECR</button>
      <button onClick={()=>dispatch(incrementByNum(3))}>INCR</button>
      <hr/>
      <Demo/>
      </div>
  );
}

export default App;
