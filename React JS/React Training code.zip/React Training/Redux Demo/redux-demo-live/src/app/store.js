import {configureStore} from '@reduxjs/toolkit'
import CounterSliceReducer from '../features/counter/CounterSlice'

export default configureStore({
    reducer:{
        counter: CounterSliceReducer,
        user: UserSliceReducer
    }
})