import './App.css';
import CustomHookDemo from './components/customHooks/CustomHookDemo';
import CustomHookDemo2 from './components/customHooks/CustomHookDemo2';
import UseCallbackDemo from './components/useCallback/UseCallbackDemo';
import UseDeferredValueDemo from './components/useDefferedValue/UseDeferredValueDemo';
import UseMemoDemo from './components/useMemo/UseMemoDemo';
import UseTransitionDemo from './components/useTransition/UseTransitionDemo';

function App() {
  return (
    <div className="App">
      {/* <UseMemoDemo/> */}
      {/* <UseCallbackDemo/> */}
      {/* <UseTransitionDemo/> */}
      {/* <UseDeferredValueDemo/> */}
      {/* <CustomHookDemo/> */}
      <CustomHookDemo2/>

    </div>
  );
}

export default App;
