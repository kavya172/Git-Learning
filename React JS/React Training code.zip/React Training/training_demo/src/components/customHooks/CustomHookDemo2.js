import React from "react";
import useFetch from "./useFetch";

const CustomHookDemo2 = () => {
  const [isLoading, data] = useFetch("https://jsonplaceholder.typicode.com/todos");
  return (
    <>
      {isLoading ? (
        <h1>LOADING.......</h1>
      ) : (
        data &&
        data.map((item) => {
          return <p key={item.id}>{item.title}</p>;
        })
      )}
    </>
  );
};

export default CustomHookDemo2;
