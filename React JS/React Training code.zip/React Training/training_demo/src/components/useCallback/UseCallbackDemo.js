import React, { useCallback, useState } from "react";
import ListDisplay from "./ListDisplay";

const UseCallbackDemo = () => {
  const [list, setList] = useState([]);
  const [counter, setCounter] = useState(0);

  const increment = () => {
    setCounter(counter + 1);
  };

  const addToList = useCallback((newItem) => {
    setList( [...list, newItem]);
  }, [list]);  

  console.log("Parent Rendered");

  return (
    <div>
      <ListDisplay list={list} addToList={addToList} />
      <hr />
      <h1>{counter}</h1>
      <button onClick={increment}>INCR</button>
      <hr />
    </div>
  );
};

export default UseCallbackDemo;

