import React, { useState, useTransition } from "react";

const UseTransitionDemo = () => {
  const [search, setSearch] = useState("");
  const [list, setList] = useState([]);
  const [isPending, startTransition] = useTransition();

  const SIZE = 100;

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
    startTransition(() => {
      const l = [];
      for (let i = 0; i < SIZE; i++) {
        l.push(e.target.value);
      }
      setList(l);
    });
  };

  return (
    <div>
    <h1>UseTransition Demo</h1>
      <input type="text" value={search} onChange={handleSearchChange} />
      {
        isPending? <h1>LOADING.....</h1>:
        list.map((item) => (
          <h3>{item}</h3>
        ))
      }
    </div>
  );
};

export default UseTransitionDemo;
